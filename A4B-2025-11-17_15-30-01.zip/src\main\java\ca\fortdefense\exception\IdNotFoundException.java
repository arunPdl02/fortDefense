package ca.fortdefense.exception;

public class IdNotFoundException extends RuntimeException{
    public IdNotFoundException(String message) {
        super(message);
    }

    public IdNotFoundException() {
    }
}
